README

to run: open in eclipse, left click game.java, select run as java application

to run tests: open in eclipse, left click src/test/java, select run as JUnit test

