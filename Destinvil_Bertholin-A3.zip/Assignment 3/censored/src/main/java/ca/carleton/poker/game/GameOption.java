package ca.carleton.poker.game;

/**
 * Options one can make when playing the game.
 * <p/>
 * 
 */
public enum GameOption {
    STAY,
    HIT,
}
