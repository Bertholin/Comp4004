package ca.carleton.poker.game.entity.card;

/**
 * Hand statuses
 * <p/>
 * 
 */
public enum HandStatus {
    WINNER,
    LOSER,
}
